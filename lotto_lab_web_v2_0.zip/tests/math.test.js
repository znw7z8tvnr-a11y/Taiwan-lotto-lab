const assert = require('node:assert/strict');
function combo(n,k){if(k<0||k>n)return 0;let x=1;for(let i=1;i<=k;i++)x=x*(n-i+1)/i;return Math.round(x)}
assert.equal(combo(39,5),575757);
assert.equal(combo(49,6),13983816);
assert.equal(combo(38,6),2760681);
assert.equal(combo(6,5),6);
assert.equal(combo(7,6),7);
assert.equal(combo(8,6),28);
for(const [N,k] of [[39,5],[49,6],[38,6]]){
  let p=0;for(let r=0;r<=k;r++)p+=combo(k,r)*combo(N-k,k-r)/combo(N,k);
  assert.ok(Math.abs(p-1)<1e-12, `${N}/${k} probability sum`);
}
console.log('All 9 mathematical checks passed');
