import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const output = new URL('../history.json', import.meta.url);
const meta = new URL('../history-status.json', import.meta.url);
const games={lotto:[49,6,0],power:[38,6,8],five:[39,5,0]};
export function validate(r){
 const g=games[r.game];if(!g)throw Error('Unsupported game '+r.game);
 const nums=Array.isArray(r.numbers)?r.numbers.map(Number):String(r.numbers??'').trim().split(/[\s,，、]+/).map(Number);
 if(nums.length!==g[1]||new Set(nums).size!==nums.length||nums.some(n=>!Number.isInteger(n)||n<1||n>g[0]))throw Error('Invalid numbers: '+r.game+'/'+r.issue);
 const date=String(r.date??''),issue=String(r.issue??'');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(date+'T00:00:00Z'))||!issue||issue.length>50)throw Error('Invalid date/issue');
 const second=g[2]?Number(r.second):null;
 if(g[2]&&(!Number.isInteger(second)||second<1||second>g[2]))throw Error('Invalid second');
 return {game:r.game,date,issue,numbers:nums.sort((a,b)=>a-b),...(g[2]?{second}:{})};
}
export function merge(existing,incoming){const map=new Map();for(const r of [...existing,...incoming]){const v=validate(r),key=v.game+'|'+v.issue,old=map.get(key);if(old&&JSON.stringify(old)!==JSON.stringify(v))throw Error('Conflict: '+key);map.set(key,v)}return [...map.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.issue.localeCompare(b.issue));}
async function main(){
 const source=process.env.LOTTO_HISTORY_SOURCE;
 if(!source){console.log('No LOTTO_HISTORY_SOURCE configured; existing history unchanged.');return;}
 let raw;
 if(/^https:\/\//.test(source)){const response=await fetch(source,{signal:AbortSignal.timeout(25000),headers:{Accept:'application/json'}});if(!response.ok)throw Error('Source HTTP '+response.status);raw=await response.json();}
 else raw=JSON.parse(await fs.readFile(source,'utf8'));
 if(!Array.isArray(raw))throw Error('Source must be normalized JSON array');
 const current=JSON.parse(await fs.readFile(output,'utf8').catch(e=>e.code==='ENOENT'?'[]':Promise.reject(e)));
 const merged=merge(current,raw);
 await fs.writeFile(output,JSON.stringify(merged,null,2)+'\n');
 const counts=Object.fromEntries(Object.keys(games).map(k=>[k,{count:merged.filter(r=>r.game===k).length,latest:merged.filter(r=>r.game===k).at(-1)?.date??null}]));
 await fs.writeFile(meta,JSON.stringify({updatedAt:new Date().toISOString(),sourceConfigured:true,records:merged.length,byGame:counts},null,2)+'\n');
 console.log('Validated '+raw.length+' incoming records; total '+merged.length);
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)main().catch(e=>{console.error(e);process.exitCode=1});
